<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lnkShop</name>
   <tag></tag>
   <elementGuidId>73885601-2feb-4518-9cca-4fa36cb63389</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@href = 'http://cms.demo.katalon.com/' and (text() = 'Shop' or . = 'Shop')]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@href = 'https://cms.demo.katalon.com/' and (text() = 'Shop' or . = 'Shop')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>http://cms.demo.katalon.com/</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Shop</value>
   </webElementProperties>
</WebElementEntity>
